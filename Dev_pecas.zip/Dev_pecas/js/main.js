(function () {
  // SHORTCUTS
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => document.querySelectorAll(sel);

  // ELEMENTOS
  const btnAdd = $("#btnAdd");
  const btnAddFull = $("#btnAddFull");
  const btnClearSig = $("#btnClearSig");
  const btnGeneratePdf = $("#btnGeneratePdf");

  const codigoInput = $("#codigoPeca");
  const serialInput = $("#serialProxxi");
  const notaInput = $("#notaFiscal");
  const inputCompleto = $("#inputCompleto");
  const serialTableBody = $("#serialTable tbody");

  const canvas = $("#signatureCanvas");
  if (!canvas) {
    console.error(
      "Canvas de assinatura não encontrado (id='signatureCanvas')."
    );
    return;
  }
  const ctx = canvas.getContext("2d");
  let isInitialized = false;

  /* ------------------------ CANVAS / ASSINATURA ------------------------ */
  // === fixCanvasDPI preservando desenho e evitando resizes inúteis ===
  // ===== fixCanvasDPI (versão estável que preserva desenho e mantém desenho funcional) =====
  let __lastCanvasCssW = 0;
  let __lastCanvasCssH = 0;
  let __lastDeviceRatio = window.devicePixelRatio || 1;

  function fixCanvasDPI() {
    if (!canvas) return;

    const computedStyle = getComputedStyle(canvas);
    const cssWidth = Math.round(parseFloat(computedStyle.width)) || 600;
    const cssHeight = Math.round(parseFloat(computedStyle.height)) || 200;
    const ratio = window.devicePixelRatio || 1;

    // se nada mudou — sair (muito importante para não apagar ao abrir teclado mobile)
    if (
      cssWidth === __lastCanvasCssW &&
      cssHeight === __lastCanvasCssH &&
      ratio === __lastDeviceRatio
    ) {
      return;
    }

    // salva o desenho atual como dataURL (forma segura)
    let dataUrl = null;
    try {
      dataUrl = canvas.toDataURL();
    } catch (e) {
      // se falhar (muito raro), apenas continue sem restaurar
      console.warn("fixCanvasDPI: toDataURL falhou:", e);
    }

    // redefine tamanho físico do canvas (em device pixels)
    canvas.width = Math.round(cssWidth * ratio);
    canvas.height = Math.round(cssHeight * ratio);

    // mantém o tamanho CSS para layout
    canvas.style.width = cssWidth + "px";
    canvas.style.height = cssHeight + "px";

    // prepara o contexto para desenhar em CSS pixels (escala física)
    ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
    ctx.lineWidth = 2;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#003366";

    // restaura a imagem previamente salva (assíncrono)
    if (dataUrl) {
      const img = new Image();
      img.onload = function () {
        try {
          // desenhar a imagem do dataURL no canvas recém redimensionado
          ctx.save();
          ctx.setTransform(1, 0, 0, 1, 0, 0); // desenha imagem em pixels do canvas
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(
            img,
            0,
            0,
            img.width,
            img.height,
            0,
            0,
            canvas.width,
            canvas.height
          );
          ctx.restore();
        } catch (err) {
          console.warn(
            "fixCanvasDPI: falha ao desenhar imagem restaurada:",
            err
          );
        }
      };
      img.onerror = function (e) {
        console.warn(
          "fixCanvasDPI: imagem de restauração falhou ao carregar:",
          e
        );
      };
      img.src = dataUrl;
    } else {
      // sem dataUrl, apenas limpa (caso inicial)
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }

    // grava valores para próxima verificação
    __lastCanvasCssW = cssWidth;
    __lastCanvasCssH = cssHeight;
    __lastDeviceRatio = ratio;
  }

  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  const handleResize = debounce(() => {
    fixCanvasDPI();
  }, 100);

  window.addEventListener("load", () => {
    fixCanvasDPI();
    window.addEventListener("orientationchange", handleResize);
    window.addEventListener("resize", handleResize);

    const dataInput = document.getElementById("data");
    if (dataInput) {
      const hoje = new Date();
      const ano = hoje.getFullYear();
      const mes = String(hoje.getMonth() + 1).padStart(2, "0");
      const dia = String(hoje.getDate()).padStart(2, "0");
      dataInput.value = `${ano}-${mes}-${dia}`;
    }
  });

  // DESENHO
  let drawing = false;
  function getPos(evt) {
    const rect = canvas.getBoundingClientRect();

    if (evt.touches && evt.touches.length) {
      return {
        x: evt.touches[0].clientX - rect.left,
        y: evt.touches[0].clientY - rect.top,
      };
    } else {
      return {
        x: evt.clientX - rect.left,
        y: evt.clientY - rect.top,
      };
    }
  }

  canvas.addEventListener("mousedown", (e) => {
    drawing = true;
    const p = getPos(e);
    ctx.beginPath();
    ctx.moveTo(p.x, p.y);
    e.preventDefault();
  });

  canvas.addEventListener("mousemove", (e) => {
    if (!drawing) return;
    const p = getPos(e);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    e.preventDefault();
  });

  ["mouseup", "mouseleave"].forEach((ev) => {
    canvas.addEventListener(ev, () => {
      if (!drawing) return;
      drawing = false;
      try {
        ctx.closePath();
      } catch (e) {}
    });
  });

  canvas.addEventListener(
    "touchstart",
    (e) => {
      drawing = true;
      const p = getPos(e);
      ctx.beginPath();
      ctx.moveTo(p.x, p.y);
      e.preventDefault();
    },
    { passive: false }
  );

  canvas.addEventListener(
    "touchmove",
    (e) => {
      if (!drawing) return;
      const p = getPos(e);
      ctx.lineTo(p.x, p.y);
      ctx.stroke();
      e.preventDefault();
    },
    { passive: false }
  );

  ["touchend", "touchcancel"].forEach((ev) => {
    canvas.addEventListener(ev, () => {
      drawing = false;
      try {
        ctx.closePath();
      } catch (e) {}
    });
  });

  function limparAssinatura() {
    ctx.save();
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.restore();
  }

  btnClearSig.addEventListener("click", limparAssinatura);

  /* ------------------------ TABELA DINÂMICA (sem alterações) ------------------------ */
  const HEADER_CODIGO = "Código";
  const HEADER_SERIAL = "Número de Série";
  const HEADER_NOTA = "Nota Fiscal";
  const HEADER_ACOES = "Ações";

  function makeActionButton(text, cls, onClick) {
    const b = document.createElement("button");
    b.type = "button";
    b.className = cls;
    b.textContent = text;
    b.addEventListener("click", onClick);
    return b;
  }

  function addRow() {
    if (!codigoInput.value.trim() || !serialInput.value.trim()) {
      alert("Preencha Código e Número de Série (Nota Fiscal é opcional).");
      return;
    }
    const tr = document.createElement("tr");
    const tdCodigo = document.createElement("td");
    const tdSerial = document.createElement("td");
    const tdNota = document.createElement("td");
    const tdActions = document.createElement("td");

    tdCodigo.textContent = codigoInput.value.trim();
    tdSerial.textContent = serialInput.value.trim();
    tdNota.textContent = notaInput.value.trim();

    tdCodigo.setAttribute("data-label", HEADER_CODIGO);
    tdSerial.setAttribute("data-label", HEADER_SERIAL);
    tdNota.setAttribute("data-label", HEADER_NOTA);
    tdActions.setAttribute("data-label", HEADER_ACOES);

    const btnEdit = makeActionButton("Editar", "edit-btn", () =>
      editarLinha(tr)
    );
    const btnDelete = makeActionButton("Excluir", "delete-btn", () =>
      excluirLinha(tr)
    );

    tdActions.appendChild(btnEdit);
    tdActions.appendChild(btnDelete);

    tr.appendChild(tdCodigo);
    tr.appendChild(tdSerial);
    tr.appendChild(tdNota);
    tr.appendChild(tdActions);

    serialTableBody.appendChild(tr);

    codigoInput.value = "";
    serialInput.value = "";
    notaInput.value = "";
  }

  function addRowFull() {
    const raw = inputCompleto.value.trim();
    if (!raw) return;
    const valores = raw
      .split(/[,.;\n\r]+|\s{2,}|[ ]+/)
      .map((v) => v.trim())
      .filter(Boolean);

    if (valores.length % 3 !== 0) {
      alert(
        "Por favor, insira valores em múltiplos de 3: Código, Serial, Nota Fiscal."
      );
      return;
    }

    for (let i = 0; i < valores.length; i += 3) {
      const tr = document.createElement("tr");
      const tdCodigo = document.createElement("td");
      const tdSerial = document.createElement("td");
      const tdNota = document.createElement("td");
      const tdActions = document.createElement("td");

      tdCodigo.textContent = valores[i] || "";
      tdSerial.textContent = valores[i + 1] || "";
      tdNota.textContent = valores[i + 2] || "";

      tdCodigo.setAttribute("data-label", HEADER_CODIGO);
      tdSerial.setAttribute("data-label", HEADER_SERIAL);
      tdNota.setAttribute("data-label", HEADER_NOTA);
      tdActions.setAttribute("data-label", HEADER_ACOES);

      const btnEdit = makeActionButton("Editar", "edit-btn", () =>
        editarLinha(tr)
      );
      const btnDelete = makeActionButton("Excluir", "delete-btn", () =>
        excluirLinha(tr)
      );

      tdActions.appendChild(btnEdit);
      tdActions.appendChild(btnDelete);

      tr.appendChild(tdCodigo);
      tr.appendChild(tdSerial);
      tr.appendChild(tdNota);
      tr.appendChild(tdActions);

      serialTableBody.appendChild(tr);
    }
    inputCompleto.value = "";
  }

  function editarLinha(tr) {
    const tds = tr.querySelectorAll("td");
    if (tds.length >= 3) {
      $("#codigoPeca").value = tds[0].textContent;
      $("#serialProxxi").value = tds[1].textContent;
      $("#notaFiscal").value = tds[2].textContent;
      tr.remove();
      codigoInput.focus();
    }
  }

  function excluirLinha(tr) {
    tr.remove();
  }

  btnAdd.addEventListener("click", addRow);
  btnAddFull.addEventListener("click", addRowFull);

  /* ------------------------ PRELOAD LOGO e UTILITÁRIOS ------------------------ */
  const logoPath = "assets/images/logosmall2.png";
  let PRELOADED_LOGO_DATAURL = null;
  let PRELOADED_LOGO_ASPECT = null;
  let PRELOADED_LOGO_OPTIMIZED = null;

  function blobToDataURL(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  async function optimizeDataUrl(
    dataUrl,
    maxWidthPx,
    mime = "image/jpeg",
    quality = 0.75
  ) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const aspect =
          (img.naturalWidth || img.width) / (img.naturalHeight || img.height);
        const targetW = Math.min(maxWidthPx, img.naturalWidth || img.width);
        const targetH = Math.round(targetW / aspect) || 1;
        const c = document.createElement("canvas");
        c.width = targetW;
        c.height = targetH;
        const cctx = c.getContext("2d");
        cctx.fillStyle = "#ffffff";
        cctx.fillRect(0, 0, c.width, c.height);
        cctx.drawImage(img, 0, 0, c.width, c.height);
        try {
          const out = c.toDataURL(mime, quality);
          resolve({ dataUrl: out, width: targetW, height: targetH, aspect });
        } catch (err) {
          reject(err);
        }
      };
      img.onerror = (e) => reject(e);
      img.src = dataUrl;
    });
  }

  function optimizeCanvasToDataUrl(
    srcCanvas,
    maxWidthPx,
    mime = "image/jpeg",
    quality = 0.75
  ) {
    const sw = srcCanvas.width;
    const sh = srcCanvas.height;
    const aspect = sw / sh || 1;
    const targetW = Math.min(maxWidthPx, sw);
    const targetH = Math.round(targetW / aspect) || 1;
    const c = document.createElement("canvas");
    c.width = targetW;
    c.height = targetH;
    const cctx = c.getContext("2d");
    cctx.fillStyle = "#ffffff";
    cctx.fillRect(0, 0, c.width, c.height);
    cctx.drawImage(srcCanvas, 0, 0, c.width, c.height);
    return c.toDataURL(mime, quality);
  }

  async function preloadLogo() {
    try {
      const res = await fetch(logoPath, { cache: "no-cache" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const blob = await res.blob();
      const dataUrl = await blobToDataURL(blob);
      PRELOADED_LOGO_DATAURL = dataUrl;

      const img = await new Promise((resolve, reject) => {
        const i = new Image();
        i.onload = () => resolve(i);
        i.onerror = reject;
        i.src = dataUrl;
      });
      PRELOADED_LOGO_ASPECT =
        (img.naturalWidth || img.width) / (img.naturalHeight || img.height);

      try {
        // reduzir largura do logo para 300px por padrão e qualidade 0.75
        const maxWidthPx = 300;
        const optimized = await optimizeDataUrl(
          PRELOADED_LOGO_DATAURL,
          maxWidthPx,
          "image/jpeg",
          0.75
        );
        PRELOADED_LOGO_OPTIMIZED = optimized.dataUrl;
      } catch (optErr) {
        PRELOADED_LOGO_OPTIMIZED = PRELOADED_LOGO_DATAURL;
      }
    } catch (err) {
      console.warn("[logo] preload falhou:", err);
      PRELOADED_LOGO_DATAURL = null;
      PRELOADED_LOGO_OPTIMIZED = null;
    }
  }
  preloadLogo().catch((e) => console.error("[logo] preload erro:", e));

  async function getLogoDataURL(url) {
    if (PRELOADED_LOGO_OPTIMIZED) return PRELOADED_LOGO_OPTIMIZED;
    try {
      const res = await fetch(url, { cache: "no-cache" });
      if (!res.ok) throw new Error("HTTP " + res.status);
      const blob = await res.blob();
      const dataUrl = await blobToDataURL(blob);
      const opt = await optimizeDataUrl(dataUrl, 300, "image/jpeg", 0.75);
      return opt.dataUrl;
    } catch (err) {
      console.warn("getLogoDataURL fetch falhou:", err);
    }

    try {
      const img = new Image();
      img.src = url;
      await new Promise((res, rej) => {
        img.onload = res;
        img.onerror = rej;
      });
      const c = document.createElement("canvas");
      c.width = img.naturalWidth || img.width;
      c.height = img.naturalHeight || img.height;
      c.getContext("2d").drawImage(img, 0, 0);
      const dataUrl = c.toDataURL("image/png");
      const opt = await optimizeDataUrl(dataUrl, 300, "image/jpeg", 0.75);
      return opt.dataUrl;
    } catch (err2) {
      console.warn("getLogoDataURL fallback image falhou:", err2);
    }
    return null;
  }

  function getImageFormatFromDataUrl(dataUrl) {
    if (!dataUrl || typeof dataUrl !== "string") return "PNG";
    const m = dataUrl.match(/^data:image\/(png|jpeg|jpg);/i);
    if (!m) return "PNG";
    const mime = m[1].toLowerCase();
    if (mime === "jpeg" || mime === "jpg") return "JPEG";
    return "PNG";
  }

  /* ------------------------ GERA PDF (ajustes na assinatura e logo) ------------------------ */
  btnGeneratePdf.addEventListener("click", async function gerarPDF() {
    try {
      // prefer optimized preloaded logo
      let logoDataUrl =
        PRELOADED_LOGO_OPTIMIZED || PRELOADED_LOGO_DATAURL || null;
      if (!logoDataUrl && PRELOADED_LOGO_DATAURL) {
        try {
          const opt = await optimizeDataUrl(
            PRELOADED_LOGO_DATAURL,
            300,
            "image/jpeg",
            0.75
          );
          logoDataUrl = opt.dataUrl;
          PRELOADED_LOGO_OPTIMIZED = logoDataUrl;
        } catch (e) {
          logoDataUrl = PRELOADED_LOGO_DATAURL;
        }
      }
      if (!logoDataUrl) {
        try {
          logoDataUrl = await getLogoDataURL(logoPath);
        } catch (e) {
          logoDataUrl = null;
        }
      }

      const { jsPDF } = window.jspdf;
      const doc = new jsPDF();

      const maxRowsPerPage = 20;
      const tableColumnNames = ["Código", "Número de Série", "Nota Fiscal"];
      const tableData = [];

      const rows = serialTableBody.rows;
      for (let i = 0; i < rows.length; i++) {
        const cells = rows[i].cells;
        const rowData = [
          cells[0] ? cells[0].textContent : "",
          cells[1] ? cells[1].textContent : "",
          cells[2] ? cells[2].textContent : "",
        ];
        tableData.push(rowData);
      }

      const formElement = $("#deliveryForm");
      const formData = new FormData(formElement);
      const formDataObject = {};
      formData.forEach((value, key) => (formDataObject[key] = value));

      let dataFormatadaPDF = "";
      let dataFormatada = "";
      if (formDataObject.data) {
        const parts = formDataObject.data.split("-");
        if (parts.length === 3) {
          dataFormatadaPDF = `${parts[2]}-${parts[1]}-${parts[0]}`;
          const dt = new Date(parts[0], parts[1] - 1, parts[2]);
          dataFormatada = dt.toLocaleDateString("pt-BR", {
            day: "numeric",
            month: "long",
            year: "numeric",
          });
        }
      }
      if (!dataFormatada) {
        const now = new Date();
        dataFormatada = now.toLocaleDateString("pt-BR", {
          day: "numeric",
          month: "long",
          year: "numeric",
        });
        dataFormatadaPDF = `${String(now.getDate()).padStart(2, "0")}-${String(
          now.getMonth() + 1
        ).padStart(2, "0")}-${now.getFullYear()}`;
      }

      function addHeaderAndFooter(pageNumber) {
        const logoMaxWidthMm = 40;
        if (logoDataUrl) {
          try {
            const fmt = getImageFormatFromDataUrl(logoDataUrl);
            let logoWidth = logoMaxWidthMm;
            let logoHeight = logoWidth / (PRELOADED_LOGO_ASPECT || 1);
            const pageWidth = doc.internal.pageSize.getWidth();
            const x = pageWidth - 15 - logoWidth;
            const y = 8;
            doc.addImage(logoDataUrl, fmt, x, y, logoWidth, logoHeight);
          } catch (e) {
            console.warn("Erro ao adicionar logo no PDF:", e);
          }
        }

        doc.setFontSize(20);
        doc.setFont(undefined, "bold");
        doc.text("Formulário de Entrega de Peças", 105, 30, {
          align: "center",
        });

        doc.setFontSize(12);
        doc.setFont(undefined, "bold");
        doc.text("Data:", 20, 44);
        doc.setFont(undefined, "normal");
        doc.text(dataFormatada, 33, 44);

        doc.setFont(undefined, "bold");
        doc.text("Nome do Recebedor:", 20, 54);
        doc.setFont(undefined, "normal");
        doc.text(formDataObject.nomeRecebedor || "", 64, 54);

        doc.setFont(undefined, "bold");
        doc.text("Nome Técnico:", 20, 64);
        doc.setFont(undefined, "normal");
        doc.text(formDataObject.nomeTecnico || "", 52, 64);

        doc.setFontSize(10);
        doc.setFont(undefined, "normal");
        doc.text(`Página ${pageNumber}`, 105, 290, { align: "center" });
      }

      let currentPage = 1;
      let startY = 75;
      if (tableData.length === 0) addHeaderAndFooter(currentPage);

      for (let i = 0; i < tableData.length; i += maxRowsPerPage) {
        if (i !== 0) {
          doc.addPage();
          currentPage++;
        }
        addHeaderAndFooter(currentPage);
        doc.autoTable({
          head: [tableColumnNames],
          body: tableData.slice(i, i + maxRowsPerPage),
          startY: startY,
          styles: { fontSize: 10 },
        });
      }

      let finalY = 0;
      if (
        doc.autoTable &&
        doc.autoTable.previous &&
        typeof doc.autoTable.previous.finalY === "number"
      ) {
        finalY = doc.autoTable.previous.finalY + 10;
      } else {
        finalY = 80;
      }

      // ----- ASSINATURA: gerar JPEG otimizado (mantendo proporção) -----
      try {
        const assinaturaOptimized = optimizeCanvasToDataUrl(
          canvas,
          600,
          "image/jpeg",
          0.6
        );
        const fmtSig = getImageFormatFromDataUrl(assinaturaOptimized);

        // carregar imagem para saber proporção real
        const imgSig = await new Promise((resolve, reject) => {
          const im = new Image();
          im.onload = () => resolve(im);
          im.onerror = reject;
          im.src = assinaturaOptimized;
        });

        // aspecto da assinatura (largura / altura)
        const aspect =
          (imgSig.naturalWidth || imgSig.width) /
            (imgSig.naturalHeight || imgSig.height) || 1;

        // limites e cálculos em mm
        const pageWidthMm = doc.internal.pageSize.getWidth();
        const leftMarginMm = 15;
        const rightMarginMm = 15;
        const availWidthMm = Math.max(
          10,
          pageWidthMm - leftMarginMm - rightMarginMm
        );

        // largura desejada base (mm). Não ultrapassar a largura disponível.
        const baseWidthMm = Math.min(60, availWidthMm);
        // calcula altura para preservar proporção
        const baseHeightMm = baseWidthMm / aspect;

        // ajustar se altura ficar muito alta
        const maxHeightMm = 80;
        let sigWidthMm = baseWidthMm;
        let sigHeightMm = baseHeightMm;
        if (sigHeightMm > maxHeightMm) {
          sigHeightMm = maxHeightMm;
          sigWidthMm = sigHeightMm * aspect;
          if (sigWidthMm > availWidthMm) {
            sigWidthMm = availWidthMm;
            sigHeightMm = sigWidthMm / aspect;
          }
        }

        const sigX = leftMarginMm;
        const sigY = finalY + 10;

        doc.addImage(
          assinaturaOptimized,
          fmtSig,
          sigX,
          sigY,
          sigWidthMm,
          sigHeightMm
        );

        // linha e nome abaixo da assinatura (posicionadas com base na altura real)
        doc.line(
          sigX,
          sigY + sigHeightMm + 5,
          sigX + Math.min(85, sigWidthMm),
          sigY + sigHeightMm + 5
        );
        doc.text(
          formDataObject.nomeRecebedor || "",
          sigX,
          sigY + sigHeightMm + 9
        );
      } catch (e) {
        console.warn("Erro ao adicionar assinatura no PDF:", e);
      }

      const fileName = `form_entrega_pecas_${
        dataFormatadaPDF || "sem_data"
      }.pdf`;
      doc.save(fileName);
      console.info("PDF gerado:", fileName);
    } catch (err) {
      console.error("Erro ao gerar PDF:", err);
      alert("Ocorreu um erro ao gerar o PDF. Veja o console para detalhes.");
    }
  });

  /* ------------------------ Leitura por Câmera (BarcodeDetector + fallback Quagga) ------------------------ */

  let cameraActive = false;
  let currentTarget = null;
  let currentStream = null;
  let barcodeDetector = null;
  let rafId = null;
  let quaggaActive = false;

  const cameraModal = document.getElementById("cameraPreviewModal");
  const cameraVideo = document.getElementById("cameraVideo");
  const closeCameraBtn = cameraModal
    ? cameraModal.querySelector(".close-camera")
    : null;

  function showCameraModal() {
    if (cameraModal) cameraModal.classList.add("show");
    if (cameraVideo) cameraVideo.setAttribute("aria-hidden", "false");
  }
  function hideCameraModal() {
    if (cameraModal) cameraModal.classList.remove("show");
    if (cameraVideo) cameraVideo.setAttribute("aria-hidden", "true");
  }

  async function startCamera(targetId) {
    // se já estiver ativo, reinicia para novo target
    if (cameraActive) {
      stopCamera();
    }

    currentTarget = targetId;
    cameraActive = true;
    showCameraModal();

    // checar suporte getUserMedia
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      alert("Navegador não suporta acesso à câmera.");
      stopCamera();
      return;
    }

    try {
      // solicitar câmera traseira preferencialmente
      currentStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
        audio: false,
      });
      // conectar ao video
      if ("srcObject" in cameraVideo) {
        cameraVideo.srcObject = currentStream;
      } else {
        cameraVideo.src = window.URL.createObjectURL(currentStream);
      }
      await cameraVideo.play();
    } catch (err) {
      console.error("Erro getUserMedia:", err);
      alert("Não foi possível acessar a câmera. Verifique permissões.");
      stopCamera();
      return;
    }

    // Tentar usar BarcodeDetector nativo
    if ("BarcodeDetector" in window) {
      try {
        // formatos comuns suportados
        const formats = [
          "code_128",
          "ean_13",
          "ean_8",
          "code_39",
          "upc_e",
          "upc_a",
          "qr_code",
        ];
        barcodeDetector = new BarcodeDetector({ formats });
      } catch (e) {
        console.warn("Construção BarcodeDetector falhou:", e);
        barcodeDetector = null;
      }
    }

    if (barcodeDetector) {
      // loop de detecção com requestAnimationFrame
      const detectFrame = async () => {
        if (!cameraActive) return;
        try {
          const barcodes = await barcodeDetector.detect(cameraVideo);
          if (barcodes && barcodes.length) {
            const bc = barcodes[0];
            const code = bc.rawValue || bc.rawText || bc?.rawValue;
            if (code) {
              handleDetected(code);
              return;
            }
          }
        } catch (err) {
          // falha em detectar via API nativa (alguns browsers lançam aqui)
          // console.debug("BarcodeDetector detect erro:", err);
        }
        rafId = requestAnimationFrame(detectFrame);
      };
      rafId = requestAnimationFrame(detectFrame);
      return;
    }

    // Se BarcodeDetector não disponível, fallback para Quagga (se existir)
    if (window.Quagga) {
      try {
        quaggaActive = true;
        // parar Quagga anterior se houver
        if (window.Quagga && typeof window.Quagga.stop === "function") {
          try {
            window.Quagga.stop();
          } catch (e) {
            /* ignore */
          }
        }
        window.Quagga.init(
          {
            inputStream: {
              name: "Live",
              type: "LiveStream",
              target: cameraVideo, // passar elemento video
              constraints: {
                facingMode: "environment",
                width: { ideal: 1280 },
                height: { ideal: 720 },
              },
            },
            decoder: {
              readers: [
                "code_128_reader",
                "ean_reader",
                "ean_8_reader",
                "code_39_reader",
                "upc_reader",
              ],
            },
            locate: true,
          },
          function (err) {
            if (err) {
              console.error("Erro ao inicializar Quagga:", err);
              quaggaActive = false;
              alert(
                "Não foi possível inicializar o leitor de códigos (Quagga)."
              );
              stopCamera();
              return;
            }
            try {
              window.Quagga.start();
            } catch (startErr) {
              console.error("Quagga start erro:", startErr);
              quaggaActive = false;
              stopCamera();
            }
          }
        );

        window.Quagga.onDetected(function (result) {
          if (!result) return;
          const code = result.codeResult && result.codeResult.code;
          if (code) {
            handleDetected(code);
          }
        });
      } catch (e) {
        console.error("Quagga fallback erro:", e);
        quaggaActive = false;
        stopCamera();
      }
      return;
    }

    // Se chegamos aqui, não há mecanismos disponíveis
    alert("Leitura por câmera não disponível neste navegador.");
    stopCamera();
  }

  function handleDetected(code) {
    try {
      const el = document.getElementById(currentTarget);
      if (!el) {
        console.warn("Elemento alvo não encontrado para id:", currentTarget);
        stopCamera();
        return;
      }

      // regra especial: inputCompleto -> se vazio define, se já tiver valor, acrescenta (não substitui)
      if (currentTarget === "inputCompleto" || el.id === "inputCompleto") {
        const existing = el.value ? el.value.trim() : "";
        if (!existing) {
          el.value = code;
        } else {
          // evitar duplicatas exatas (opcional)
          const parts = existing
            .split(/[,]+/)
            .map((s) => s.trim())
            .filter(Boolean);
          //if (!parts.includes(code)) {      -> Retirado 18/09
            el.value = existing + "," + code;
          //}                                 -> Retirado 18/09
        }
      } else {
        el.value = code;
      }
    } catch (e) {
      console.error("Erro ao aplicar código detectado:", e);
    } finally {
      stopCamera();
    }
  }

  function stopCamera() {
    cameraActive = false;
    currentTarget = null;

    // limpar RAF
    if (rafId) {
      cancelAnimationFrame(rafId);
      rafId = null;
    }

    // parar BarcodeDetector (não precisa de stop), apenas esconder modal
    hideCameraModal();

    // parar stream tracks
    try {
      if (currentStream && currentStream.getTracks) {
        currentStream.getTracks().forEach((t) => t.stop());
      }
    } catch (e) {
      console.warn("erro ao parar tracks:", e);
    }
    currentStream = null;

    // parar Quagga se ativo
    try {
      if (window.Quagga && typeof window.Quagga.stop === "function") {
        window.Quagga.stop();
      }
    } catch (e) {
      console.warn("erro ao parar Quagga:", e);
    }
    quaggaActive = false;
  }

  // Fechar ao clicar no botão
  if (closeCameraBtn) {
    closeCameraBtn.addEventListener("click", stopCamera);
  }

  // ligar botão câmera nos campos (event delegation)
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll(".btn-camera").forEach((button) => {
      button.addEventListener("click", function () {
        const target = this.getAttribute("data-target");
        if (target) startCamera(target);
      });
    });
  });

  window.iniciarLeituraCodigo = function (idInput) {
    startCamera(idInput);
  };

  /* ------------------------ FIM Leitura por Câmera ------------------------ */
})();
